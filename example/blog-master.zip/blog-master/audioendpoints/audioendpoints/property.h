// property.h

HRESULT LogProperty(PROPERTYKEY key, const PROPVARIANT &val);
