#include <initguid.h>
#include <windows.h>
#include <mmdeviceapi.h>
#include <propkey.h>
#include <devpkey.h>
#include <functiondiscoverykeys_devpkey.h>
