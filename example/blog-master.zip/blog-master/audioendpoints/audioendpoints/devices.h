// devices.h

HRESULT AudioDevices();
HRESULT AudioDevice(IMMDevice *pMMDevice);
