// endpoints.h

HRESULT AudioEndpoints();