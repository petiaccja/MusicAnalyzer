#include <windows.h>
#include <initguid.h>
#include <mfapi.h>
#include <ks.h>