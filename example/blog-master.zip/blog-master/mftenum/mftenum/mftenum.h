// mftenum.h

HRESULT EnumerateMFTs();