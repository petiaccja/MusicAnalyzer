// details.h

void LogDetails(ACMDRIVERDETAILS details);