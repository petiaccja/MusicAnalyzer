// acmenum.h

MMRESULT EnumerateACMDrivers();