// guids.cpp

#include <initguid.h>
#include "common.h"
