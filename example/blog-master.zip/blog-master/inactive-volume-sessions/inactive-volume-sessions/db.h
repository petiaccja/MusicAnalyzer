// db.h

float DbFromAmp(float a);

