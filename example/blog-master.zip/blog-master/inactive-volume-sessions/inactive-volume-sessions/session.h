// session.h

void LogSessions(IMMDevice *pMMDevice);

