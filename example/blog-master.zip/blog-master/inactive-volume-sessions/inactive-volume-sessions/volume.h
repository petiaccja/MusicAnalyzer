// volume.h

HRESULT ListVolumesForDevices();
