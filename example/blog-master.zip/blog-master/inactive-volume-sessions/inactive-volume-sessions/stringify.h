// stringify.h

LPCWSTR StringFromAudioSessionState(AudioSessionState state);
LPCWSTR StringFromDataFlow(EDataFlow flow);