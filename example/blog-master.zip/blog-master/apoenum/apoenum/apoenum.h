// apoenum.h

HRESULT EnumerateAudioProcessingObjects();