// details.h

HRESULT LogDetails(PAPO_REG_PROPERTIES pApo);