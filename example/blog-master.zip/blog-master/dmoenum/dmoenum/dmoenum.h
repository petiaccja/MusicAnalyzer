// dmoenum.h

HRESULT EnumerateDMOs();