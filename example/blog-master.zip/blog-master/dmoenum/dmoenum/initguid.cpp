#include <windows.h>
#include <initguid.h>
#include <dmoreg.h>