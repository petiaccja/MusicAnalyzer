#include <windows.h>
#include <initguid.h>
#include <dshow.h>
#include <ks.h>
#include <ksmedia.h>
#include <bdatypes.h>
#include <bdamedia.h>
// #include <qedit.h>