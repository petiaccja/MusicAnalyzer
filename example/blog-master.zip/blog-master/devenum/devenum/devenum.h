// devenum.h

HRESULT EnumerateDirectShowFilters();