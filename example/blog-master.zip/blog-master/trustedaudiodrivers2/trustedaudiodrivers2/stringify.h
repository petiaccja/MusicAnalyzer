// stringify.h

LPCTSTR MFPolicyManagerAction2String(MFPOLICYMANAGER_ACTION a);
LPCTSTR OutputSubType2String(GUID guidOutputSubType);
LPCTSTR ProtectionSchema2String(GUID guidProtectionSchema);
CString Attributes2String(DWORD dwAttributes);