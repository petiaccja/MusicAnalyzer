// outputschema.h

HRESULT CreateTrustedAudioDriversOutputSchema(
	DWORD dwConfigData,
	GUID guidOriginatorID,
	IMFOutputSchema **ppMFOutputSchema
);
