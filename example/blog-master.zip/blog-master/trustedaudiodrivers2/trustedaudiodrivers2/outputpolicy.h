// outputpolicy.h

HRESULT CreateTrustedAudioDriversOutputPolicy(
	DWORD dwConfigData,
	IMFOutputPolicy **ppMFOutputPolicy
);
