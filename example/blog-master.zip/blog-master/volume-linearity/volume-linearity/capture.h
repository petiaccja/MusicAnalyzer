// capture.h

HRESULT Capture();