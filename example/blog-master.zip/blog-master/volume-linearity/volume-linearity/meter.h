// meter.h

HRESULT GetAudioMeterInformation(IAudioMeterInformation **ppAudioMeterInformation);