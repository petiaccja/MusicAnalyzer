// endpoint.h

HRESULT Endpoint();