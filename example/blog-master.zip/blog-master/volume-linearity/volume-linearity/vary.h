// vary.h

enum EVary {
    eSignal,
    eAudioStreamVolume,
    eSimpleAudioVolume,
    eChannelAudioVolume,
    eAudioEndpointVolume,
    eCaptureVolume,
};