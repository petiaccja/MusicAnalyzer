// render.h

HRESULT Render(IAudioMeterInformation *pAudioMeterInformation, EVary which);